

<?php $__env->startSection('title',"Nueva Planilla"); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center my-5">
    <form action="<?php echo e(route('createPlanilla')); ?>" method="POST" class="row g-3 my-5 col-md-6 justify-content-center">
        
        <?php echo csrf_field(); ?>

        <div class="row">
            <div class="col-12 col-md-6 my-2">
              <input type="text" class="form-control" name="cliente" placeholder="Cliente" aria-label="Cliente">
                <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger">Campo obligatorio</strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 col-md-6 my-2">
              <input type="number" class="form-control" name="contacto" placeholder="Contacto" aria-label="Contacto">
                <?php $__errorArgs = ['contacto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger">Mas de 10 caracteres</strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="row">
            <div class="col-12 my-2">
                <input type="text" class="form-control" name="articulo" placeholder="Articulo" aria-label="Articulo">
                <?php $__errorArgs = ['cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <strong class="text-danger">Campo obligatorio</strong>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-12 my-2">
                <textarea class="form-control" name="detalle" placeholder="Detalle" ></textarea>
            </div>
        </div>
        <button type="submit" class="btn btn-primary my-4 col-3 col-md-2 " >Submit</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abadd\OneDrive\Escritorio\juliancastro\caca\electro440\resources\views/planillas/createPlanilla.blade.php ENDPATH**/ ?>