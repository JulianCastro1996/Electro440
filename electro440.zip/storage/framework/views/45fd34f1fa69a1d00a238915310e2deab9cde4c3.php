

<?php $__env->startSection('title',"Listado de planillas"); ?>

<?php $__env->startSection('content'); ?>
<table class="table">
    <thead>
        <tr class="table-dark">
            <th scope="col">ID</th>
            <th scope="col">Cliente</th>
            <th scope="col">Articulo</th>
            <th scope="col">Accion</th>
        </tr>
    </thead>

    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $planillas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php if($p->presupuesto!= null): ?>
            <tr class="table-success" >
            <?php else: ?>
            <tr class="table-danger">
            <?php endif; ?>
                <th scope="row" onclick="location.href='<?php echo e(route('planilla', ['planillaID' => $p->id])); ?>';"><?php echo e($p->id); ?></th>
                <td onclick="location.href='<?php echo e(route('planilla', ['planillaID' => $p->id])); ?>';"><?php echo e($p->cliente); ?></td>
                <td><?php echo e($p->articulo); ?></td>
                <td><a type="button" href="<?php echo e(route('deletePlanilla', ['id' => $p->id])); ?>" class="btn btn-danger">Borrar</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td>"Sin Planillas"</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abadd\OneDrive\Escritorio\juliancastro\caca\electro440\resources\views/planillas/planillaList.blade.php ENDPATH**/ ?>