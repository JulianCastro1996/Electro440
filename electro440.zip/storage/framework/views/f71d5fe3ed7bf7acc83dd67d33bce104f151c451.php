

<?php $__env->startSection('title',"Solicitud Nº: $p->id "); ?>

<?php $__env->startSection('content'); ?>
<div class="row justify-content-center my-5">
    <div class="card col-md-6 ">
        <div class="card-header text-center text-bg-dark ">
            <h2>Planilla Nº: <?php echo e($p->id); ?></h2>
        </div>
        <ul class="list-group list-group-flush">
            <li class="list-group-item text-bg-info d-flex justify-content-between align-items-center">
                <span><strong>Cliente:</strong> <?php echo e($p->cliente); ?>.</span>
            </li>
            <li class="list-group-item text-bg-info d-flex justify-content-between align-items-center">
                <span><strong>Contacto:</strong> <?php echo e($p->contacto); ?>.</span>
            </li>
            <li class="list-group-item text-bg-info d-flex justify-content-between align-items-center">
                <span><strong>Articulo:</strong> <?php echo e($p->articulo); ?>.</span>
            </li>
            <li class="list-group-item text-bg-info d-flex justify-content-between align-items-center">
                <span><strong>Detalle:</strong>  <?php echo e($p->detalle); ?>.</span>
            </li>
            <li class="list-group-item text-bg-info d-flex justify-content-between align-items-center">
                <span><strong>Cliente:</strong> <?php echo e($p->cliente); ?>.</span>
            </li>
        <?php if($p->presupuesto != null): ?>
            <li class="list-group-item text-bg-warning d-flex justify-content-between align-items-center">
                <span><strong>Presupuesto:</strong>  <?php echo e($p->presupuesto); ?>.</span>
            </li>
            <li class="list-group-item text-bg-warning d-flex justify-content-between align-items-center">
                <span><strong>Diagnostico:</strong> <?php echo e($p->diagnostico); ?>.</span>
            </li>
        </ul>                    
        <?php else: ?>
        </ul>
            <form  action="<?php echo e(route('presupPlanilla')); ?>" method="POST" class="row  justify-content-center ">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center">
                <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                <div class="col-12 my-2">
                    <input type="number" class="form-control" name="presupuesto" placeholder="Presupuesto" aria-label="Presupuesto">
                    <?php $__errorArgs = ['presupuesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <strong class="text-danger">Campo obligatorio</strong>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 my-2">
                    <textarea class="form-control" name="diagnostico" placeholder="Diagnostico" ></textarea>
                </div>
                <input type="submit" class="btn btn-primary my-3 col-3 " value="Presupuestar">
            </div>
            </form>
        <?php endif; ?>                
        <div class="card-footer  text-bg-dark">
            Recibido: <?php echo e($p->created_at); ?>

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\abadd\OneDrive\Escritorio\juliancastro\caca\electro440\resources\views/planillas/planilla.blade.php ENDPATH**/ ?>